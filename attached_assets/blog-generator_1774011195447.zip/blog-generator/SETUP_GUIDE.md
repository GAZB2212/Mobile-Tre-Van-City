# Automated Blog Generator — Setup Guide
## Mobile Tyre Van City · Replit Installation

This guide walks you through adding the automated blog system to your existing Replit project in four steps. Once set up, the system will automatically generate and publish a new SEO blog post every Monday morning at 8am — no manual work required.

---

## How It Works

```
┌─────────────────────────────────────────────────────────────┐
│                    EVERY MONDAY 8AM                         │
│                                                             │
│  Cron Job → Picks next keyword → Calls OpenAI API          │
│           → Generates full blog post → Saves to JSON file  │
│           → Post is live on your site instantly            │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                    YOUR REACT FRONTEND                      │
│                                                             │
│  /blog          → BlogList.jsx  → GET /api/blog            │
│  /blog/:slug    → BlogPost.jsx  → GET /api/blog/:slug      │
└─────────────────────────────────────────────────────────────┘
```

---

## Step 1 — Add the Server File

Copy `blogServer.js` into your Replit project. If your project already has a server (e.g., `server/index.js`), you have two options:

**Option A — Merge into your existing server**
Copy the routes and cron setup from `blogServer.js` into your existing Express server file.

**Option B — Run as a separate service**
Add `blogServer.js` as a standalone file and start it alongside your main server. In your `package.json`, update the start script:

```json
"scripts": {
  "start": "node server/index.js & node server/blogServer.js"
}
```

---

## Step 2 — Install Dependencies

In your Replit Shell, run:

```bash
npm install openai node-cron
```

`express` and `cors` are likely already installed. If not:

```bash
npm install express cors
```

---

## Step 3 — Add Your Secrets in Replit

Go to **Tools → Secrets** in your Replit project and add:

| Secret Key | Value | Description |
| :--- | :--- | :--- |
| `OPENAI_API_KEY` | `sk-...your key...` | Your OpenAI API key (get from platform.openai.com) |
| `ADMIN_SECRET` | Any strong password | Protects the manual generate endpoint |

**Where to get your OpenAI API key:**
1. Go to [platform.openai.com](https://platform.openai.com)
2. Click your profile → View API Keys
3. Create a new key and paste it into Replit Secrets

**Cost:** Using `gpt-4.1-mini`, each blog post costs approximately **$0.01–$0.03** (1–3 pence). Generating one post per week costs less than £1.50 per year.

---

## Step 4 — Add the Frontend Routes

In your main React router file (usually `App.jsx` or `main.jsx`), add two new routes:

```jsx
import BlogList from './components/BlogList';
import BlogPost from './components/BlogPost';

// Inside your <Routes> block:
<Route path="/blog" element={<BlogList />} />
<Route path="/blog/:slug" element={<BlogPost />} />
```

Add a "Blog" link to your navigation menu:

```jsx
<a href="/blog">BLOG</a>
```

Add the following to your `.env` file (or Replit Secrets):

```
VITE_API_URL=https://your-replit-app-url.replit.app
```

---

## Step 5 — Add Blog to Your Sitemap

In your `sitemap.xml` generation logic, add entries for `/blog` and each individual post slug. The API endpoint `GET /api/blog?limit=1000` returns all posts with their slugs for this purpose.

---

## Manually Triggering a Post

You can generate a post at any time without waiting for Monday by calling the API:

```bash
curl -X POST https://your-site.replit.app/api/blog/generate \
  -H "Content-Type: application/json" \
  -H "x-admin-secret: YOUR_ADMIN_SECRET" \
  -d '{"keyword": "mobile tyre fitting van equipment list UK"}'
```

Or to use the next keyword in the automatic list, omit the body:

```bash
curl -X POST https://your-site.replit.app/api/blog/generate \
  -H "x-admin-secret: YOUR_ADMIN_SECRET"
```

---

## Changing the Schedule

The schedule is controlled by the `CRON_SCHEDULE` variable in `blogServer.js`.

| Schedule | Cron Expression |
| :--- | :--- |
| Every Monday at 8am | `0 0 8 * * 1` |
| Every Wednesday and Friday at 9am | `0 0 9 * * 3,5` |
| Every day at 7am | `0 0 7 * * *` |
| Twice a week (Mon + Thu) at 8am | `0 0 8 * * 1,4` |

---

## Adding More Keywords

Open `blogServer.js` and add new keywords to the `KEYWORD_LIST` array. The system works through the list in order, one keyword per scheduled run. Once all keywords are used, it starts again from the top.

---

## File Storage

All generated posts are stored in `server/blog_posts.json`. This file is created automatically on first run. You can open it in Replit to view, edit, or delete posts directly.

To set a post to draft (hidden from the public site):

```bash
curl -X PATCH https://your-site.replit.app/api/blog/POST_ID/status \
  -H "Content-Type: application/json" \
  -H "x-admin-secret: YOUR_ADMIN_SECRET" \
  -d '{"status": "draft"}'
```

---

## Tailwind CSS Requirement

`BlogPost.jsx` uses Tailwind's `@tailwindcss/typography` plugin for the `prose` classes that style the post content. Install it with:

```bash
npm install @tailwindcss/typography
```

Then add it to your `tailwind.config.js`:

```js
plugins: [require('@tailwindcss/typography')]
```

---

## Summary of API Endpoints

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/blog` | List all published posts (paginated) |
| `GET` | `/api/blog/:slug` | Get a single post by slug |
| `POST` | `/api/blog/generate` | Manually generate a new post (admin) |
| `GET` | `/api/blog/admin/all` | List all posts including drafts (admin) |
| `PATCH` | `/api/blog/:id/status` | Change a post's status (admin) |

---

*Built for Mobile Tyre Van City by Manus AI · March 2026*
