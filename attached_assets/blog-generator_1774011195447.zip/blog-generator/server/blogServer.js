/**
 * Mobile Tyre Van City — Automated Blog Generator
 * ================================================
 * Drop this file into your Replit project's server folder.
 * It exposes REST API endpoints for your React frontend and
 * auto-generates a new SEO blog post on a configurable schedule.
 *
 * Requirements (add to your package.json):
 *   npm install openai node-cron express cors
 */

const express = require('express');
const cors = require('cors');
const cron = require('node-cron');
const OpenAI = require('openai');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(express.json());

// ─────────────────────────────────────────────
// CONFIGURATION — edit these values
// ─────────────────────────────────────────────
const OPENAI_API_KEY = process.env.OPENAI_API_KEY; // Set in Replit Secrets
const POSTS_FILE = path.join(__dirname, 'blog_posts.json');
const PORT = process.env.PORT || 3001;

// How often to auto-generate a new post.
// Default: every Monday at 8am.
// Cron format: second minute hour day month weekday
const CRON_SCHEDULE = '0 0 8 * * 1';

// The keyword list to cycle through for auto-generation.
// Add as many as you like — the system picks the next unused one each run.
const KEYWORD_LIST = [
  'how to start a mobile tyre fitting business UK',
  'mobile tyre fitting van equipment list UK',
  'how much does a mobile tyre fitting business make',
  'REACT motorway certification UK tyre fitter',
  'mobile tyre van conversion cost UK',
  'best van for mobile tyre fitting business UK',
  'mobile tyre fitting business insurance UK',
  'how to get customers for mobile tyre fitting business',
  'mobile tyre fitting vs tyre shop which is more profitable',
  'VW Crafter mobile tyre van conversion UK',
  'Ford Transit mobile tyre van setup UK',
  'how to finance a mobile tyre van UK',
  'mobile tyre fitting business plan UK',
  'TPMS diagnostics mobile tyre fitter',
  'mobile tyre fitting business startup costs UK 2026',
];

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────

/** Load all posts from the JSON file store */
function loadPosts() {
  if (!fs.existsSync(POSTS_FILE)) {
    fs.writeFileSync(POSTS_FILE, JSON.stringify({ posts: [], usedKeywords: [] }, null, 2));
  }
  return JSON.parse(fs.readFileSync(POSTS_FILE, 'utf8'));
}

/** Save posts back to the JSON file store */
function savePosts(data) {
  fs.writeFileSync(POSTS_FILE, JSON.stringify(data, null, 2));
}

/** Convert a title string into a URL-safe slug */
function slugify(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-');
}

/** Pick the next keyword that hasn't been used yet */
function getNextKeyword(usedKeywords) {
  const unused = KEYWORD_LIST.filter(k => !usedKeywords.includes(k));
  if (unused.length === 0) {
    // All keywords used — reset and start again
    return KEYWORD_LIST[0];
  }
  return unused[0];
}

// ─────────────────────────────────────────────
// CORE: AI BLOG POST GENERATOR
// ─────────────────────────────────────────────

async function generateBlogPost(keyword) {
  console.log(`[Blog Generator] Generating post for keyword: "${keyword}"`);

  const openai = new OpenAI({ apiKey: OPENAI_API_KEY });

  const systemPrompt = `You are an expert SEO content writer for Mobile Tyre Van City, a UK company based in Bromborough, Wirral (CH62 3QL) that builds and sells professionally converted mobile tyre fitting vans. The business also offers van finance (FCA authorised), tyre supplier connections, and training.

Your job is to write high-quality, SEO-optimised blog posts that:
- Are genuinely helpful and informative for people considering starting a mobile tyre fitting business
- Naturally position Mobile Tyre Van City as the go-to solution
- Include the target keyword naturally in the title, introduction, and throughout the body
- Are written in British English
- Are between 900 and 1,200 words
- Include a clear meta title (max 60 chars) and meta description (max 155 chars)
- Use H2 subheadings to break up the content
- End with a strong call to action mentioning the phone number 0151 203 8500 and the website

IMPORTANT: Return your response as a valid JSON object with exactly these fields:
{
  "metaTitle": "string (max 60 chars)",
  "metaDescription": "string (max 155 chars)",
  "title": "string (the H1 blog post title)",
  "content": "string (the full blog post body in plain HTML — use <h2>, <p>, <strong>, <ul>, <li> tags only)"
}`;

  const userPrompt = `Write a complete SEO blog post targeting the keyword: "${keyword}"`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4.1-mini',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ],
    temperature: 0.7,
    response_format: { type: 'json_object' },
  });

  const raw = response.choices[0].message.content;
  const parsed = JSON.parse(raw);

  const now = new Date();
  const post = {
    id: crypto.randomUUID(),
    slug: slugify(parsed.title),
    keyword: keyword,
    metaTitle: parsed.metaTitle,
    metaDescription: parsed.metaDescription,
    title: parsed.title,
    content: parsed.content,
    publishedAt: now.toISOString(),
    status: 'published', // change to 'draft' if you want to review before publishing
  };

  console.log(`[Blog Generator] Post created: "${post.title}" (slug: ${post.slug})`);
  return post;
}

// ─────────────────────────────────────────────
// SCHEDULED AUTO-GENERATION
// ─────────────────────────────────────────────

cron.schedule(CRON_SCHEDULE, async () => {
  console.log('[Blog Generator] Scheduled run triggered...');
  try {
    const data = loadPosts();
    const keyword = getNextKeyword(data.usedKeywords);
    const post = await generateBlogPost(keyword);
    data.posts.unshift(post); // newest first
    data.usedKeywords.push(keyword);
    savePosts(data);
    console.log(`[Blog Generator] Scheduled post published: "${post.title}"`);
  } catch (err) {
    console.error('[Blog Generator] Scheduled generation failed:', err.message);
  }
}, {
  timezone: 'Europe/London',
});

// ─────────────────────────────────────────────
// REST API ENDPOINTS
// ─────────────────────────────────────────────

/**
 * GET /api/blog
 * Returns all published posts (newest first), with optional pagination.
 * Query params: ?page=1&limit=10
 */
app.get('/api/blog', (req, res) => {
  try {
    const data = loadPosts();
    const published = data.posts.filter(p => p.status === 'published');
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const start = (page - 1) * limit;
    const paginated = published.slice(start, start + limit);
    res.json({
      total: published.length,
      page,
      limit,
      posts: paginated.map(p => ({
        id: p.id,
        slug: p.slug,
        title: p.title,
        metaDescription: p.metaDescription,
        publishedAt: p.publishedAt,
        keyword: p.keyword,
      })),
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load posts' });
  }
});

/**
 * GET /api/blog/:slug
 * Returns a single post by slug (for individual blog post pages).
 */
app.get('/api/blog/:slug', (req, res) => {
  try {
    const data = loadPosts();
    const post = data.posts.find(p => p.slug === req.params.slug && p.status === 'published');
    if (!post) return res.status(404).json({ error: 'Post not found' });
    res.json(post);
  } catch (err) {
    res.status(500).json({ error: 'Failed to load post' });
  }
});

/**
 * POST /api/blog/generate
 * Manually trigger generation of a new blog post.
 * Body (optional): { "keyword": "your custom keyword" }
 * Protect this endpoint with the ADMIN_SECRET header in production.
 */
app.post('/api/blog/generate', async (req, res) => {
  // Simple secret check — set ADMIN_SECRET in Replit Secrets
  const secret = req.headers['x-admin-secret'];
  if (process.env.ADMIN_SECRET && secret !== process.env.ADMIN_SECRET) {
    return res.status(401).json({ error: 'Unauthorised' });
  }

  try {
    const data = loadPosts();
    const keyword = req.body.keyword || getNextKeyword(data.usedKeywords);
    const post = await generateBlogPost(keyword);
    data.posts.unshift(post);
    if (!data.usedKeywords.includes(keyword)) {
      data.usedKeywords.push(keyword);
    }
    savePosts(data);
    res.json({ success: true, post });
  } catch (err) {
    console.error('[Blog Generator] Manual generation failed:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * GET /api/blog/admin/all
 * Returns all posts including drafts (for admin review).
 */
app.get('/api/blog/admin/all', (req, res) => {
  const secret = req.headers['x-admin-secret'];
  if (process.env.ADMIN_SECRET && secret !== process.env.ADMIN_SECRET) {
    return res.status(401).json({ error: 'Unauthorised' });
  }
  const data = loadPosts();
  res.json(data.posts);
});

/**
 * PATCH /api/blog/:id/status
 * Update a post's status (e.g., draft → published, or published → archived).
 * Body: { "status": "published" | "draft" | "archived" }
 */
app.patch('/api/blog/:id/status', (req, res) => {
  const secret = req.headers['x-admin-secret'];
  if (process.env.ADMIN_SECRET && secret !== process.env.ADMIN_SECRET) {
    return res.status(401).json({ error: 'Unauthorised' });
  }
  const data = loadPosts();
  const post = data.posts.find(p => p.id === req.params.id);
  if (!post) return res.status(404).json({ error: 'Post not found' });
  post.status = req.body.status;
  savePosts(data);
  res.json({ success: true, post });
});

// ─────────────────────────────────────────────
// START SERVER
// ─────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`[Blog Generator] Server running on port ${PORT}`);
  console.log(`[Blog Generator] Auto-generation scheduled: ${CRON_SCHEDULE} (Europe/London)`);
  console.log(`[Blog Generator] ${KEYWORD_LIST.length} keywords loaded`);
});
