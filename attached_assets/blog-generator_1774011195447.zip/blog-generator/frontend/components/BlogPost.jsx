/**
 * BlogPost.jsx
 * ============
 * Displays a single blog post fetched by slug from the URL.
 * Handles meta tags for SEO (requires react-helmet-async or similar).
 *
 * Usage: Add <Route path="/blog/:slug" element={<BlogPost />} /> to your router.
 */

import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:3001';

export default function BlogPost() {
  const { slug } = useParams();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLoading(true);
    fetch(`${API_BASE}/api/blog/${slug}`)
      .then(res => {
        if (!res.ok) throw new Error('Post not found');
        return res.json();
      })
      .then(data => {
        setPost(data);
        setLoading(false);
        // Update page title and meta description dynamically
        document.title = `${data.metaTitle} | Mobile Tyre Van City`;
        const metaDesc = document.querySelector('meta[name="description"]');
        if (metaDesc) metaDesc.setAttribute('content', data.metaDescription);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, [slug]);

  const formatDate = (iso) =>
    new Date(iso).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });

  if (loading) {
    return (
      <div className="flex justify-center items-center py-24">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#8bc440]" />
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="text-center py-24">
        <h1 className="text-white text-2xl font-bold mb-4">Post Not Found</h1>
        <p className="text-gray-400 mb-8">
          This article doesn't exist or has been removed.
        </p>
        <Link
          to="/blog"
          className="bg-[#8bc440] text-black font-bold px-6 py-3 rounded-lg hover:bg-[#7ab330] transition-colors"
        >
          ← Back to Blog
        </Link>
      </div>
    );
  }

  return (
    <article className="max-w-3xl mx-auto px-4 py-16">
      {/* Breadcrumb */}
      <nav className="text-sm text-gray-500 mb-8">
        <Link to="/" className="hover:text-[#8bc440]">Home</Link>
        <span className="mx-2">/</span>
        <Link to="/blog" className="hover:text-[#8bc440]">Blog</Link>
        <span className="mx-2">/</span>
        <span className="text-gray-300">{post.title}</span>
      </nav>

      {/* Post Header */}
      <header className="mb-10">
        <p className="text-[#8bc440] text-sm font-semibold uppercase tracking-widest mb-3">
          Mobile Tyre Business Guide
        </p>
        <h1 className="text-white text-3xl md:text-4xl font-bold leading-tight mb-4">
          {post.title}
        </h1>
        <p className="text-gray-400 text-sm">
          Published {formatDate(post.publishedAt)} · By Mobile Tyre Van City
        </p>
      </header>

      {/* Post Content — rendered from HTML string */}
      <div
        className="prose prose-invert prose-lg max-w-none
          prose-headings:text-white prose-headings:font-bold
          prose-h2:text-2xl prose-h2:mt-10 prose-h2:mb-4
          prose-p:text-gray-300 prose-p:leading-relaxed
          prose-strong:text-white
          prose-li:text-gray-300
          prose-a:text-[#8bc440] prose-a:no-underline hover:prose-a:underline"
        dangerouslySetInnerHTML={{ __html: post.content }}
      />

      {/* CTA Banner */}
      <div className="mt-16 bg-[#8bc440] rounded-2xl p-8 text-center">
        <h2 className="text-black text-2xl font-bold mb-3">
          Ready to Start Your Mobile Tyre Business?
        </h2>
        <p className="text-black/80 mb-6">
          Browse our ready-to-go vans or configure your perfect build online.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            to="/stock"
            className="bg-black text-white font-bold px-6 py-3 rounded-lg hover:bg-gray-900 transition-colors"
          >
            View Van Stock
          </Link>
          <Link
            to="/configurator"
            className="bg-white text-black font-bold px-6 py-3 rounded-lg hover:bg-gray-100 transition-colors"
          >
            Configure Your Van
          </Link>
        </div>
        <p className="text-black/70 text-sm mt-4">
          Or call us: <strong>0151 203 8500</strong> · Mon–Fri 9am–5:30pm
        </p>
      </div>

      {/* Back link */}
      <div className="mt-10 text-center">
        <Link
          to="/blog"
          className="text-[#8bc440] font-semibold hover:underline"
        >
          ← Back to all articles
        </Link>
      </div>
    </article>
  );
}
