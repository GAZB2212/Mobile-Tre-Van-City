/**
 * BlogList.jsx
 * ============
 * Displays a grid of blog post cards fetched from the API.
 * Add this to your existing React site.
 *
 * Usage: <BlogList />
 */

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:3001';

export default function BlogList() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const LIMIT = 9;

  useEffect(() => {
    setLoading(true);
    fetch(`${API_BASE}/api/blog?page=${page}&limit=${LIMIT}`)
      .then(res => res.json())
      .then(data => {
        setPosts(data.posts);
        setTotal(data.total);
        setLoading(false);
      })
      .catch(() => {
        setError('Failed to load blog posts.');
        setLoading(false);
      });
  }, [page]);

  const formatDate = (iso) =>
    new Date(iso).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });

  if (loading) {
    return (
      <div className="flex justify-center items-center py-24">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#8bc440]" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-24 text-red-400">
        <p>{error}</p>
      </div>
    );
  }

  if (posts.length === 0) {
    return (
      <div className="text-center py-24 text-gray-400">
        <p>No blog posts yet. Check back soon.</p>
      </div>
    );
  }

  const totalPages = Math.ceil(total / LIMIT);

  return (
    <section className="py-16 px-4 max-w-7xl mx-auto">
      <div className="text-center mb-12">
        <span className="text-[#8bc440] text-sm font-semibold uppercase tracking-widest">
          Knowledge Hub
        </span>
        <h1 className="text-4xl font-bold text-white mt-2">
          Mobile Tyre Business Blog
        </h1>
        <p className="text-gray-400 mt-4 max-w-2xl mx-auto">
          Expert guides, tips, and industry insights to help you start and grow
          your mobile tyre fitting business.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {posts.map(post => (
          <Link
            key={post.id}
            to={`/blog/${post.slug}`}
            className="group bg-gray-900 border border-gray-800 rounded-xl overflow-hidden hover:border-[#8bc440] transition-all duration-300"
          >
            {/* Placeholder header image */}
            <div className="h-48 bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
              <span className="text-[#8bc440] text-5xl">🔧</span>
            </div>

            <div className="p-6">
              <p className="text-xs text-gray-500 mb-2">{formatDate(post.publishedAt)}</p>
              <h2 className="text-white font-bold text-lg leading-snug group-hover:text-[#8bc440] transition-colors duration-200 mb-3">
                {post.title}
              </h2>
              <p className="text-gray-400 text-sm line-clamp-3">
                {post.metaDescription}
              </p>
              <span className="inline-block mt-4 text-[#8bc440] text-sm font-semibold">
                Read more →
              </span>
            </div>
          </Link>
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center gap-3 mt-12">
          <button
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-4 py-2 rounded-lg bg-gray-800 text-white disabled:opacity-40 hover:bg-[#8bc440] transition-colors"
          >
            ← Previous
          </button>
          <span className="px-4 py-2 text-gray-400">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="px-4 py-2 rounded-lg bg-gray-800 text-white disabled:opacity-40 hover:bg-[#8bc440] transition-colors"
          >
            Next →
          </button>
        </div>
      )}
    </section>
  );
}
